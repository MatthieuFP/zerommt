"""
zerommt.

An open-source framework for zero-shot multimodal machine translation inference.
"""

__version__ = "0.1.0"
__author__ = 'Matthieu Futeral'

from .main import create_model
